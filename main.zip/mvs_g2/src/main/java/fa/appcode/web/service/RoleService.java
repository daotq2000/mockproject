package fa.appcode.web.service;

import fa.appcode.web.entities.Role;

public interface RoleService extends BaseService<Role,Integer> {
}
