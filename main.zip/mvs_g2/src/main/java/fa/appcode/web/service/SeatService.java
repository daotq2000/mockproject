package fa.appcode.web.service;

public interface SeatService {
}
