package fa.appcode.web.commons.utility;

public class HTTP {
    public static final int NOT_FOUND = 404;
    public static final int BAD_REQUEST = 400;
    public static final int INTERNAL_SERVER = 500;
    public static final int NON_AUTHORIZE = 401;
    public static final int OK = 200;

}
