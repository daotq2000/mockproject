package fa.appcode.web.service;

import fa.appcode.web.entities.DateMovie;
import fa.appcode.web.entities.DateMovieId;

public interface DateMovieService extends BaseService<DateMovie, DateMovieId> {
}
