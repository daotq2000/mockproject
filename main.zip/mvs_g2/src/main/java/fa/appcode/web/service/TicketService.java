package fa.appcode.web.service;

public interface TicketService {
}
